@echo off
setlocal EnableExtensions EnableDelayedExpansion
set VERSION=9.3.1
set EXPECTED_SHA256=b266d5ff6b90eada6dc3b20cb090e3731302e553a27c5d3e4df1f0d76beaff06
set BASE=%USERPROFILE%\.gradle\slf-admin-bootstrap
set HOME_DIR=%BASE%\gradle-%VERSION%
set BIN=%HOME_DIR%\bin\gradle.bat
set ZIP=%BASE%\gradle-%VERSION%-bin.zip
set TMP=%ZIP%.part
if not exist "%BIN%" (
  if not exist "%BASE%" mkdir "%BASE%"
  if not exist "%ZIP%" (
    echo Mengunduh Gradle %VERSION% dari distribusi resmi...
    if exist "%TMP%" del /q "%TMP%"
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%TMP%'"
    if errorlevel 1 exit /b 1
    for /f %%H in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 -LiteralPath '%TMP%').Hash.ToLower()"') do set ACTUAL_SHA=%%H
    if /I not "!ACTUAL_SHA!"=="%EXPECTED_SHA256%" (
      del /q "%TMP%"
      echo Checksum Gradle tidak cocok. Arsip ditolak.
      exit /b 1
    )
    move /y "%TMP%" "%ZIP%" >nul
  )
  for /f %%H in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 -LiteralPath '%ZIP%').Hash.ToLower()"') do set ACTUAL_SHA=%%H
  if /I not "!ACTUAL_SHA!"=="%EXPECTED_SHA256%" (
    del /q "%ZIP%"
    echo Checksum Gradle tidak cocok. Arsip ditolak.
    exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%BASE%' -Force"
  if errorlevel 1 exit /b 1
)
call "%BIN%" %*
endlocal
