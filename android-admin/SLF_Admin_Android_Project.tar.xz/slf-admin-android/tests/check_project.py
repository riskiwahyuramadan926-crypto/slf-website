from pathlib import Path
import re
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
main = (root/'app/src/main/java/id/legacyfrontier/admin/MainActivity.kt').read_text()
api = (root/'app/src/main/java/id/legacyfrontier/admin/ApiClient.kt').read_text()
secure = (root/'app/src/main/java/id/legacyfrontier/admin/SecureStore.kt').read_text()
manifest = root/'app/src/main/AndroidManifest.xml'
ET.parse(manifest)

required_modules = [
    'home', 'orders', 'tickets', 'support', 'reviews', 'customers', 'activity',
    'announcements', 'notes', 'products', 'promos', 'reports', 'finance',
    'site-content', 'wiki', 'studio', 'access'
]
for module in required_modules:
    assert f'Module("{module}"' in main, f'Missing module: {module}'

for endpoint in [
    '/api/admin/me', '/api/admin/orders', '/api/admin/tickets', '/api/admin/support',
    '/api/admin/reviews', '/api/admin/customers', '/api/admin/activity',
    '/api/admin/announcements', '/api/admin/notes', '/api/admin/products',
    '/api/admin/promos', '/api/admin/reports', '/api/admin/finance',
    '/api/admin/site-content', '/api/admin/wiki', '/api/admin/site-design'
]:
    assert endpoint in main, f'Missing API integration: {endpoint}'

assert 'https://legacy-frontier.web.id' in api
assert 'Authorization", "Bearer $secret"' in api
assert 'AndroidKeyStore' in secure and 'AES/GCM/NoPadding' in secure
assert 'android:usesCleartextTraffic="false"' in manifest.read_text()
assert 'android:allowBackup="false"' in manifest.read_text()
assert 'WebView' not in main and 'android.webkit' not in main
assert not re.search(r'(OWNER_SECRET|ADMIN_SECRET)\s*[:=]\s*[\"\'][^\"\']{8,}', main)
assert main.count('refresh(page)') >= 1
assert 'refresh(page)\n            refresh(page)' not in main

print(f'PASS: {len(required_modules)} modules, 16 API routes, Android XML, HTTPS, bearer auth, Keystore, no WebView, no hardcoded secrets.')
