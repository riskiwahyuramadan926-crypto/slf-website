package id.legacyfrontier.admin

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    const val BASE_URL = "https://legacy-frontier.web.id"

    fun get(path: String, secret: String): JSONObject = request("GET", path, secret, null)

    fun post(path: String, secret: String, body: JSONObject): JSONObject =
        request("POST", path, secret, body)

    fun delete(path: String, secret: String): JSONObject =
        request("DELETE", path, secret, null)

    fun request(method: String, path: String, secret: String, body: JSONObject?): JSONObject {
        require(path.startsWith("/api/")) { "Endpoint tidak diizinkan." }
        require(method in setOf("GET", "POST", "DELETE")) { "Metode API tidak diizinkan." }
        val url = URL(BASE_URL + path)
        require(url.protocol == "https" && url.host == "legacy-frontier.web.id") { "Host API tidak diizinkan." }
        val connection = (url.openConnection() as HttpURLConnection).apply {
            instanceFollowRedirects = false
            requestMethod = method
            connectTimeout = 15_000
            readTimeout = 20_000
            useCaches = false
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $secret")
            setRequestProperty("Cache-Control", "no-store")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (body != null) {
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { if (raw.isBlank()) JSONObject() else JSONObject(raw) }
                catch (_: Exception) { JSONObject().put("error", "Respons server bukan JSON yang valid.") }
            if (status !in 200..299) {
                throw ApiException(json.optString("error").ifBlank { "Permintaan gagal (HTTP $status)." }, status)
            }
            return json
        } finally {
            connection.disconnect()
        }
    }
}

class ApiException(message: String, val status: Int) : Exception(message)
