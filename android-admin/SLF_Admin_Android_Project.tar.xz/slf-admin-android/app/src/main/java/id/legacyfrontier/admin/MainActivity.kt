package id.legacyfrontier.admin

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Reviews
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Web
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.ExistingWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.time.LocalDate
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF080F1D)
private val Navy2 = Color(0xFF0D1728)
private val Panel = Color(0xFF101C30)
private val PanelRaised = Color(0xFF17253C)
private val Cyan = Color(0xFF86E7EF)
private val Lavender = Color(0xFFAC9DFF)
private val MainText = Color(0xFFEDF4FF)
private val Muted = Color(0xFFB4C2D8)
private val Green = Color(0xFF81E5BF)
private val Yellow = Color(0xFFF0D998)
private val Red = Color(0xFFFB90A6)

private data class Module(val id: String, val title: String, val subtitle: String, val ownerOnly: Boolean = false)
private val modules = listOf(
    Module("home", "Ringkasan", "Dashboard operasional"),
    Module("orders", "Pesanan & Transaksi", "Verifikasi dan proses order"),
    Module("tickets", "Tiket Re-entry", "Status tiket pemain"),
    Module("support", "Pusat Bantuan", "Tiket dan balasan pemain"),
    Module("reviews", "Ulasan", "Rating dan balasan Store"),
    Module("customers", "Pelanggan", "Riwayat pembeli"),
    Module("activity", "Aktivitas", "Log tindakan Admin"),
    Module("announcements", "Pengumuman", "Informasi resmi SLF"),
    Module("notes", "Catatan Tim", "Tugas dan tindak lanjut"),
    Module("products", "Produk Store", "Katalog dan harga", true),
    Module("promos", "Kode Promo", "Diskon dan penggunaan", true),
    Module("reports", "Statistik & Laporan", "Ringkasan penjualan", true),
    Module("finance", "Kas & Keuangan", "Pemasukan dan pengeluaran", true),
    Module("site-content", "Editor Website", "Teks dan kartu konten", true),
    Module("wiki", "Perpustakaan Wiki", "Buku dan artikel", true),
    Module("studio", "SLF Studio", "Konfigurasi desain website", true),
    Module("access", "Akses & Koneksi", "Role, database, dan kesehatan API", true),
    Module("more", "Semua Operasional", "Daftar seluruh modul")
)
private val titles = modules.associate { it.id to it.title }
private val ownerOnly = modules.filter { it.ownerOnly }.map { it.id }.toSet()

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Operational records can contain customer contact information and finance details.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        setContent { SlfAdminApp() }
    }
}

@Composable
private fun SlfTheme(content: @Composable () -> Unit) {
    val scheme = androidx.compose.material3.darkColorScheme(
        primary = Cyan,
        onPrimary = Navy,
        secondary = Lavender,
        onSecondary = Navy,
        background = Navy,
        onBackground = MainText,
        surface = Panel,
        onSurface = MainText,
        surfaceVariant = PanelRaised,
        onSurfaceVariant = Muted,
        error = Red
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
private fun SlfAdminApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var secret by remember { mutableStateOf(SecureStore.read(context).orEmpty()) }
    var role by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val notificationsPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun startBackgroundChecks() {
        val constraints = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
        val request = PeriodicWorkRequestBuilder<AdminNotificationWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "slf-admin-operations-notifications",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
        val initial = OneTimeWorkRequestBuilder<AdminNotificationWorker>().setConstraints(constraints).build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "slf-admin-initial-notification-sync", ExistingWorkPolicy.KEEP, initial
        )
    }

    fun stopBackgroundChecks() {
        WorkManager.getInstance(context).cancelUniqueWork("slf-admin-operations-notifications")
    }

    suspend fun authenticate(candidate: String, persist: Boolean) {
        loading = true
        loginError = ""
        try {
            val response = withContext(Dispatchers.IO) { ApiClient.get("/api/admin/me", candidate) }
            val accessRole = response.optString("role")
            if (accessRole !in setOf("owner", "admin")) throw Exception("Role akun tidak dikenali oleh server SLF.")
            secret = candidate
            role = accessRole
            if (persist) SecureStore.save(context, candidate)
            startBackgroundChecks()
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationsPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } catch (error: Exception) {
            role = ""
            // If a saved credential is rejected by the server, remove it even during
            // silent startup authentication; otherwise the app would retry it forever.
            if (persist || (error is ApiException && error.status in setOf(401, 403))) {
                SecureStore.clear(context)
                secret = ""
                stopBackgroundChecks()
            }
            loginError = error.message ?: "Login gagal. Periksa koneksi dan kode akses."
        } finally {
            loading = false
        }
    }

    LaunchedEffect(Unit) {
        if (secret.isNotBlank()) authenticate(secret, persist = false)
    }

    SlfTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            if (role.isBlank()) {
                LoginScreen(
                    loading = loading,
                    error = loginError,
                    onLogin = { candidate -> scope.launch { authenticate(candidate, persist = true) } }
                )
            } else {
                OperationsShell(
                    secret = secret,
                    role = role,
                    onLogout = {
                        SecureStore.clear(context)
                        stopBackgroundChecks()
                        context.getSharedPreferences("slf_admin_notification_state", Context.MODE_PRIVATE).edit().clear().apply()
                        secret = ""
                        role = ""
                    }
                )
            }
        }
    }
}

@Composable
private fun LoginScreen(loading: Boolean, error: String, onLogin: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    Box(
        Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Navy, Navy2, Color(0xFF1A1A39)))).padding(22.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Panel),
            shape = RoundedCornerShape(26.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(58.dp).background(PanelRaised, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                    Text("✦", color = Cyan, style = MaterialTheme.typography.headlineLarge)
                }
                Text("SLF ADMIN", style = MaterialTheme.typography.labelLarge, color = Cyan, fontWeight = FontWeight.Bold)
                Text("Ruang operasional", style = MaterialTheme.typography.headlineMedium, color = MainText, fontWeight = FontWeight.Bold)
                Text("Masuk menggunakan OWNER_SECRET atau ADMIN_SECRET yang sama dengan panel resmi SLF.", color = Muted)
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Kode akses Owner / Admin") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                if (error.isNotBlank()) Text(error, color = Red, style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = { onLogin(input.trim()) },
                    enabled = !loading && input.trim().length >= 32,
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    if (loading) androidx.compose.material3.CircularProgressIndicator(Modifier.size(20.dp), color = Navy, strokeWidth = 2.dp)
                    else Text("Masuk ke SLF Admin", fontWeight = FontWeight.Bold)
                }
                Text("Kunci akses disimpan terenkripsi menggunakan Android Keystore. Aplikasi tidak membuat atau mengubah kode akses server.", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OperationsShell(secret: String, role: String, onLogout: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val lifecycleOwner = LocalLifecycleOwner.current
    val snackbar = remember { SnackbarHostState() }
    var page by remember { mutableStateOf("home") }
    var data by remember { mutableStateOf(JSONObject()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var editor by remember { mutableStateOf<String?>(null) }
    var editingRecord by remember { mutableStateOf<JSONObject?>(null) }
    var confirmAction by remember { mutableStateOf<ActionSpec?>(null) }
    var studioJson by remember { mutableStateOf("") }

    suspend fun refresh(target: String = page) {
        if (target == "more") return
        if (ownerOnly.contains(target) && role != "owner") return
        loading = true
        error = ""
        try {
            val path = when (target) {
                "home", "orders" -> "/api/admin/orders"
                "tickets" -> "/api/admin/tickets"
                "support" -> "/api/admin/support"
                "reviews" -> "/api/admin/reviews"
                "customers" -> "/api/admin/customers"
                "activity" -> "/api/admin/activity"
                "announcements" -> "/api/admin/announcements"
                "notes" -> "/api/admin/notes"
                "products" -> "/api/admin/products"
                "promos" -> "/api/admin/promos"
                "reports" -> "/api/admin/reports?from=${LocalDate.now().minusDays(29)}&to=${LocalDate.now()}"
                "finance" -> "/api/admin/finance?from=${LocalDate.now().minusDays(29)}&to=${LocalDate.now()}"
                "site-content" -> "/api/admin/site-content"
                "wiki" -> "/api/admin/wiki"
                "studio" -> "/api/admin/site-design"
                "access" -> "/api/admin/me"
                else -> "/api/admin/orders"
            }
            data = withContext(Dispatchers.IO) { ApiClient.get(path, secret) }
            if (target == "studio") studioJson = data.optJSONObject("design")?.toString(2) ?: "null"
            if (target == "access") {
                val health = withContext(Dispatchers.IO) { ApiClient.get("/api/health", secret) }
                data.put("health", health)
            }
        } catch (exception: Exception) {
            if (exception is ApiException && exception.status == 401) onLogout()
            error = exception.message ?: "Gagal memuat data."
        } finally {
            loading = false
        }
    }

    suspend fun sendAction(path: String, body: JSONObject, success: String, reloadPage: String = page, method: String = "POST") {
        loading = true
        error = ""
        try {
            withContext(Dispatchers.IO) { ApiClient.request(method, path, secret, if (method == "DELETE") null else body) }
            snackbar.showSnackbar(success)
            refresh(reloadPage)
        } catch (exception: Exception) {
            if (exception is ApiException && exception.status == 401) onLogout()
            error = exception.message ?: "Aksi gagal."
        } finally {
            loading = false
        }
    }

    // Refresh the currently open operational module while the app is in the foreground.
    LaunchedEffect(page, lifecycleOwner) {
        lifecycleOwner.lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            refresh(page)
            while (true) {
                delay(45_000)
                refresh(page)
            }
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Navy2, drawerContentColor = MainText) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text("✦  SLF ADMIN", color = Cyan, fontWeight = FontWeight.ExtraBold)
                    Text(if (role == "owner") "OWNER · AKSES PENUH" else "ADMIN · OPERASIONAL", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
                Divider(color = PanelRaised)
                LazyColumn(contentPadding = PaddingValues(vertical = 8.dp)) {
                    items(modules.filter { it.id != "more" && (!it.ownerOnly || role == "owner") }) { module ->
                        androidx.compose.material3.NavigationDrawerItem(
                            label = { Column { Text(module.title, fontWeight = FontWeight.SemiBold); Text(module.subtitle, color = Muted, style = MaterialTheme.typography.labelSmall) } },
                            selected = page == module.id,
                            onClick = { page = module.id; scope.launch { drawerState.close() } },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 2.dp),
                            icon = { Icon(moduleIcon(module.id), contentDescription = null, tint = if (page == module.id) Cyan else Muted) }
                        )
                    }
                    item {
                        Divider(Modifier.padding(vertical = 8.dp), color = PanelRaised)
                        androidx.compose.material3.NavigationDrawerItem(
                            label = { Text("Keluar dari aplikasi") },
                            selected = false,
                            onClick = { scope.launch { drawerState.close() }; onLogout() },
                            modifier = Modifier.padding(horizontal = 10.dp),
                            icon = { Icon(Icons.Default.Logout, null, tint = Red) }
                        )
                    }
                }
            }
        }
    ) {
        Scaffold(
            containerColor = Navy,
            contentWindowInsets = WindowInsets.statusBars,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(titles[page] ?: "SLF Admin", color = MainText, fontWeight = FontWeight.Bold)
                            Text("SURVIVAL LEGACY FRONTIER", color = Cyan, style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    navigationIcon = { IconButton(onClick = { scope.launch { drawerState.open() } }) { Icon(Icons.Default.Menu, "Menu", tint = MainText) } },
                    actions = {
                        IconButton(onClick = { scope.launch { refresh() } }, enabled = !loading) { Icon(Icons.Default.Refresh, "Muat ulang", tint = Cyan) }
                        IconButton(onClick = onLogout) { Icon(Icons.Default.Logout, "Keluar", tint = Muted) }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Navy2, contentColor = MainText) {
                    val quick = listOf("home", "orders", "tickets", "support", "more")
                    quick.forEach { id ->
                        NavigationBarItem(
                            selected = page == id,
                            onClick = { page = id },
                            icon = { Icon(moduleIcon(id), contentDescription = null) },
                            label = { Text(if (id == "tickets") "Re-entry" else titles[id] ?: "Lainnya", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            alwaysShowLabel = false
                        )
                    }
                }
            },
            snackbarHost = { SnackbarHost(snackbar) }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (error.isNotBlank()) {
                    Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF3C2030))) {
                        Text(error, Modifier.padding(12.dp), color = Red, style = MaterialTheme.typography.bodySmall)
                    }
                }
                if (loading) androidx.compose.material3.LinearProgressIndicator(Modifier.fillMaxWidth(), color = Cyan, trackColor = Panel)
                when (page) {
                    "more" -> MoreScreen(role) { page = it }
                    "home" -> DashboardScreen(data, role) { page = it }
                    else -> ModuleScreen(
                        page = page,
                        data = data,
                        role = role,
                        onCreate = { type -> editingRecord = null; editor = type },
                        onEdit = { type, record -> editingRecord = record; editor = type },
                        onAction = { spec -> confirmAction = spec },
                        onCopy = { text ->
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("SLF Admin", text))
                            scope.launch { snackbar.showSnackbar("Tersalin ke clipboard") }
                        },
                        onExternal = { url -> runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } }
                    )
                }
            }
        }
    }

    if (editor != null) {
        EditorDialog(
            type = editor!!,
            record = editingRecord,
            studioJson = studioJson,
            onStudioJsonChange = { studioJson = it },
            onDismiss = { editor = null; editingRecord = null },
            onSave = { payload ->
                val type = editor!!
                editor = null
                editingRecord = null
                scope.launch {
                    when (type) {
                        "studio" -> {
                            try {
                                val design = JSONObject(studioJson)
                                sendAction("/api/admin/site-design", JSONObject().put("design", design), "Desain tersimpan", "studio")
                            } catch (_: Exception) { error = "JSON desain tidak valid. Periksa format sebelum menyimpan." }
                        }
                        "wiki-category", "wiki-article" -> sendAction("/api/admin/wiki", payload, "Data Wiki tersimpan", "wiki")
                        "site-content" -> sendAction("/api/admin/site-content", payload, "Konten website tersimpan", "site-content")
                        else -> {
                            val endpoint = when (type) {
                                "support" -> "/api/admin/support"
                                "review" -> "/api/admin/reviews"
                                "announcement" -> "/api/admin/announcements"
                                "note" -> "/api/admin/notes"
                                "product" -> "/api/admin/products"
                                "promo" -> "/api/admin/promos"
                                "finance" -> "/api/admin/finance"
                                else -> "/api/admin/notes"
                            }
                            sendAction(endpoint, payload, "Perubahan tersimpan")
                        }
                    }
                }
            }
        )
    }

    confirmAction?.let { action ->
        AlertDialog(
            onDismissRequest = { confirmAction = null },
            title = { Text(action.title) },
            text = { Text(action.message) },
            confirmButton = {
                Button(onClick = {
                    confirmAction = null
                    scope.launch { sendAction(action.endpoint, action.body, action.success, action.reloadPage, action.method) }
                }) { Text(action.confirmLabel) }
            },
            dismissButton = { TextButton(onClick = { confirmAction = null }) { Text("Batal") } },
            containerColor = Panel,
            titleContentColor = MainText,
            textContentColor = Muted
        )
    }
}

private data class ActionSpec(
    val title: String,
    val message: String,
    val endpoint: String,
    val body: JSONObject,
    val success: String,
    val reloadPage: String,
    val confirmLabel: String = "Lanjutkan",
    val method: String = "POST"
)

@Composable
private fun MoreScreen(role: String, onOpen: (String) -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Pusat modul", color = MainText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Semua ruang operasional website SLF dalam aplikasi native.", color = Muted) }
        items(modules.filter { it.id != "more" && (!it.ownerOnly || role == "owner") }) { module ->
            Card(
                modifier = Modifier.fillMaxWidth().clickable { onOpen(module.id) },
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(17.dp)
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(PanelRaised, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Icon(moduleIcon(module.id), null, tint = Cyan)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(module.title, color = MainText, fontWeight = FontWeight.SemiBold); Text(module.subtitle, color = Muted, style = MaterialTheme.typography.bodySmall) }
                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                }
            }
        }
    }
}

@Composable
private fun DashboardScreen(data: JSONObject, role: String, onOpen: (String) -> Unit) {
    val stats = data.optJSONObject("stats") ?: JSONObject()
    val orders = data.optJSONArray("orders") ?: JSONArray()
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(PanelRaised, Panel))).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("CONTROL CENTER", color = Cyan, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Text("Halo, ${role.uppercase()}", color = MainText, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                    Text("Pantau ruang operasional Survival Legacy Frontier.", color = Muted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusChip("API SLF", Green)
                        StatusChip("D1 melalui server", Cyan)
                    }
                }
            }
        }
        item {
            Text("Ringkasan Store", color = MainText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("Total pesanan", stats.optLong("total").toString(), Modifier.weight(1f))
                    MetricCard("Menunggu bayar", stats.optLong("pending").toString(), Modifier.weight(1f), Yellow)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricCard("Sedang diproses", stats.optLong("processing").toString(), Modifier.weight(1f), Lavender)
                    MetricCard("Omzet terverifikasi", rupiah(stats.optLong("revenue")), Modifier.weight(1f), Green)
                }
            }
        }
        item {
            Text("Akses cepat", color = MainText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickButton("Pesanan", Icons.Default.ReceiptLong, Modifier.weight(1f)) { onOpen("orders") }
                QuickButton("Re-entry", Icons.Default.AssignmentTurnedIn, Modifier.weight(1f)) { onOpen("tickets") }
                QuickButton("Bantuan", Icons.Default.Chat, Modifier.weight(1f)) { onOpen("support") }
            }
        }
        item { Text("Pesanan terbaru", color = MainText, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
        if (orders.length() == 0) {
            item { EmptyCard("Belum ada data pesanan. Tarik untuk memuat ulang.") }
        } else {
            items(minOf(orders.length(), 6)) { index ->
                val item = orders.optJSONObject(index) ?: JSONObject()
                SimpleRecordCard(
                    title = item.optString("product_name", "Pesanan"),
                    subtitle = "${item.optString("minecraft_name")} · ${item.optString("id")}",
                    status = item.optString("status"),
                    detail = rupiah(item.optLong("total"))
                )
            }
            item { OutlinedButton(onClick = { onOpen("orders") }, modifier = Modifier.fillMaxWidth()) { Text("Buka seluruh pesanan") } }
        }
        item { Text("Catatan: angka di atas berasal dari API panel SLF, bukan data contoh.", color = Muted, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun ModuleScreen(
    page: String,
    data: JSONObject,
    role: String,
    onCreate: (String) -> Unit,
    onEdit: (String, JSONObject) -> Unit,
    onAction: (ActionSpec) -> Unit,
    onCopy: (String) -> Unit,
    onExternal: (String) -> Unit
) {
    val arrayKey = when (page) {
        "orders" -> "orders"
        "tickets" -> "tickets"
        "support" -> "tickets"
        "reviews" -> "reviews"
        "customers" -> "customers"
        "activity" -> "activities"
        "announcements" -> "announcements"
        "notes" -> "notes"
        "products" -> "products"
        "promos" -> "promos"
        "site-content" -> "items"
        "wiki" -> "articles"
        else -> ""
    }
    val records = data.optJSONArray(arrayKey) ?: JSONArray()
    var searchText by remember(page) { mutableStateOf("") }
    val filteredIndices = remember(page, records, searchText) {
        (0 until records.length()).filter { index ->
            searchText.isBlank() || (records.optJSONObject(index)?.toString()?.contains(searchText, ignoreCase = true) == true)
        }
    }

    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(titles[page] ?: "SLF Admin", color = MainText, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(moduleDescription(page), color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                val canCreate = page in setOf("announcements", "notes", "products", "promos", "finance", "site-content", "wiki")
                if (canCreate) FilledTonalButton(onClick = { onCreate(createType(page)) }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(4.dp)); Text("Tambah") }
            }
        }
        if (page in setOf("orders", "tickets", "support", "reviews", "customers", "activity", "announcements", "notes", "products", "promos", "site-content", "wiki")) {
            item {
                OutlinedTextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Cari ${titles[page]?.lowercase() ?: "data"}") },
                    singleLine = true
                )
            }
        }
        when (page) {
            "orders" -> {
                val stats = data.optJSONObject("stats") ?: JSONObject()
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricCard("Menunggu", stats.optLong("pending").toString(), Modifier.weight(1f), Yellow)
                        MetricCard("Terverifikasi", stats.optLong("paid").toString(), Modifier.weight(1f), Green)
                    }
                }
            }
            "reports" -> {
                item { ReportSummary(data) }
                item { Text("Ringkasan harian", color = MainText, fontWeight = FontWeight.Bold) }
                val daily = data.optJSONArray("daily") ?: JSONArray()
                items(daily.length()) { i ->
                    val row = daily.optJSONObject(i) ?: JSONObject()
                    SimpleRecordCard(row.optString("day"), "${row.optLong("orders")} pesanan", "", rupiah(row.optLong("revenue")))
                }
                item { Text("Produk teratas", color = MainText, fontWeight = FontWeight.Bold) }
                val products = data.optJSONArray("products") ?: JSONArray()
                items(products.length()) { i ->
                    val row = products.optJSONObject(i) ?: JSONObject()
                    SimpleRecordCard(row.optString("product_name"), "${row.optLong("orders")} pesanan", "", rupiah(row.optLong("revenue")))
                }
            }
            "finance" -> {
                item { FinanceSummary(data) }
                item { Text("Rincian kas", color = MainText, fontWeight = FontWeight.Bold) }
            }
            "studio" -> {
                item {
                    SimpleRecordCard("Desain website", "${data.optJSONObject("design")?.optJSONArray("elementEdits")?.length() ?: 0} perubahan elemen", "", if (data.optBoolean("storageReady")) "Media GitHub aktif" else "Media URL / aset lokal")
                    Text("Editor visual lengkap di website tetap tersedia. Aplikasi ini menyediakan pembacaan dan penyimpanan konfigurasi desain JSON melalui API yang sama.", color = Muted)
                    Button(onClick = { onEdit("studio", JSONObject().put("design", data.optJSONObject("design") ?: JSONObject())) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Edit, null); Text("Edit konfigurasi desain") }
                }
            }
            "access" -> {
                item { AccessScreen(data, role, onExternal) }
            }
            "tickets" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada tiket re-entry.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    val status = item.optString("status")
                    val id = item.optString("id")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard("${item.optString("minecraft_name")} · ${item.optString("product_name")}", "$id · ${item.optString("season_id")} · Order ${item.optString("order_status")}", status, item.optString("created_at"))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onCopy("${item.optString("minecraft_name")} · $id · ${item.optString("status")}") }, modifier = Modifier.weight(1f)) { Text("Salin detail") }
                            if (status == "PENDING") {
                                Button(onClick = { onAction(ActionSpec("Selesaikan tiket", "Pastikan proses re-entry untuk ${item.optString("minecraft_name")} benar-benar sudah selesai.", "/api/admin/ticket-status", JSONObject().put("ticketId", id).put("status", "COMPLETED"), "Status tiket diperbarui", "tickets")) }, modifier = Modifier.weight(1f)) { Text("Tandai selesai") }
                            } else if (status == "COMPLETED") {
                                OutlinedButton(onClick = { onAction(ActionSpec("Aktifkan kembali tiket", "Pulihkan tiket ini hanya bila status sebelumnya keliru.", "/api/admin/ticket-status", JSONObject().put("ticketId", id).put("status", "ACTIVE"), "Tiket dipulihkan", "tickets")) }, modifier = Modifier.weight(1f)) { Text("Aktifkan lagi") }
                            }
                        }
                    }
                }
            }
            "orders" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada pesanan Store.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    val id = item.optString("id")
                    val status = item.optString("status")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(
                            item.optString("product_name", "Pesanan"),
                            "${item.optString("minecraft_name")} · ${item.optString("platform")} · $id",
                            status,
                            "${rupiah(item.optLong("total"))} · ${item.optString("created_at")}"
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = { onCopy("Order $id\nPemain: ${item.optString("minecraft_name")}\nWhatsApp: ${item.optString("whatsapp")}\nProduk: ${item.optString("product_name")}\nTotal: ${rupiah(item.optLong("total"))}\nStatus: $status") }, modifier = Modifier.weight(1f)) { Text("Salin") }
                            if (item.optString("whatsapp").isNotBlank()) OutlinedButton(onClick = { onExternal("https://wa.me/${item.optString("whatsapp").filter(Char::isDigit)}") }, modifier = Modifier.weight(1f)) { Text("WhatsApp") }
                            when (status) {
                                "PENDING_PAYMENT" -> {
                                    Button(onClick = { onAction(ActionSpec("Verifikasi pembayaran", "Cocokkan transaksi dan nominal langsung di DANA Bisnis. Screenshot bukti saja tidak cukup. Lanjutkan verifikasi order $id?", "/api/admin/verify-payment", JSONObject().put("orderId", id), "Pembayaran terverifikasi", "orders", "Verifikasi")) }, modifier = Modifier.weight(1f)) { Text("Verifikasi") }
                                }
                                "PAID" -> Button(onClick = { onAction(ActionSpec("Mulai proses", "Mulai pemrosesan order $id setelah pembayaran benar-benar diverifikasi.", "/api/admin/process", JSONObject().put("orderId", id), "Pesanan masuk proses", "orders")) }, modifier = Modifier.weight(1f)) { Text("Proses") }
                                "PROCESSING" -> Button(onClick = { onAction(ActionSpec("Tandai selesai", "Pastikan produk benar-benar sudah diberikan kepada pemain ${item.optString("minecraft_name")}.", "/api/admin/complete", JSONObject().put("orderId", id), "Pesanan ditandai selesai", "orders")) }, modifier = Modifier.weight(1f)) { Text("Selesai") }
                            }
                        }
                        if (status == "PAID") {
                            Button(onClick = { onAction(ActionSpec("Tandai selesai", "Pastikan produk sudah diberikan sebelum menyelesaikan pesanan.", "/api/admin/complete", JSONObject().put("orderId", id), "Pesanan ditandai selesai", "orders")) }, modifier = Modifier.fillMaxWidth()) { Text("Tandai selesai") }
                        }
                        if (status == "PENDING_PAYMENT") {
                            OutlinedButton(onClick = { onAction(ActionSpec("Batalkan transaksi", "Batalkan hanya bila pembeli belum membayar. Pembatalan juga dapat membatalkan tiket re-entry yang terkait.", "/api/admin/cancel", JSONObject().put("orderId", id), "Pesanan dibatalkan", "orders", "Batalkan")) }, modifier = Modifier.fillMaxWidth()) { Text("Batalkan transaksi") }
                        }
                    }
                }
            }
            "support" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada tiket bantuan.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(item.optString("subject"), "${item.optString("player_name")} · ${item.optString("id")} · ${item.optString("contact")}", item.optString("status"), item.optString("message"))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onEdit("support", item) }, modifier = Modifier.weight(1f)) { Text("Tindak lanjuti") }
                            OutlinedButton(onClick = { onCopy("Tiket ${item.optString("id")}\n${item.optString("player_name")}\n${item.optString("contact")}\n${item.optString("subject")}\n${item.optString("message")}") }, modifier = Modifier.weight(1f)) { Text("Salin detail") }
                        }
                        val contact = item.optString("contact")
                        val wa = contact.filter(Char::isDigit)
                        if (wa.length >= 8) OutlinedButton(onClick = { onExternal("https://wa.me/$wa") }, modifier = Modifier.fillMaxWidth()) { Text("Hubungi via WhatsApp") }
                    }
                }
            }
            "reviews" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada ulasan masuk.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard("${item.optString("player_name")} · ${item.optInt("rating")}/5", "Order ${item.optString("order_id")}", "Ulasan", item.optString("comment", "Tanpa komentar"))
                        Text("Balasan saat ini: ${item.optString("reply", "Belum ada balasan")}", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { onEdit("review", item) }, modifier = Modifier.fillMaxWidth()) { Text("Balas ulasan") }
                    }
                }
            }
            "customers" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada data pelanggan.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    SimpleRecordCard(item.optString("minecraft_name"), "${item.optString("platform")} · ${item.optString("whatsapp")} · ${item.optString("email")}", "${item.optLong("order_count")} order · ${item.optLong("paid_orders")} dibayar", "Belanja terverifikasi: ${rupiah(item.optLong("verified_spend"))}")
                }
            }
            "activity" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada aktivitas tercatat.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    SimpleRecordCard("${item.optString("action")} · ${item.optString("entity_type")}", "${item.optString("actor")} · ${item.optString("entity_id")}", "Aktivitas", "${item.optString("created_at")}\n${item.optJSONObject("details")?.toString() ?: ""}")
                }
            }
            "announcements" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada pengumuman.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(item.optString("title"), item.optString("id"), if (item.optBoolean("active")) "Aktif" else "Nonaktif", item.optString("body"))
                        Button(onClick = { onEdit("announcement", item) }, modifier = Modifier.fillMaxWidth()) { Text("Edit pengumuman") }
                    }
                }
            }
            "notes" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada catatan tim.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(item.optString("title"), "${item.optString("category")} · ${item.optString("priority")} · ${item.optString("created_by")}", item.optString("status"), item.optString("body"))
                        Button(onClick = {
                            val newStatus = if (item.optString("status") == "DONE") "OPEN" else "DONE"
                            onAction(ActionSpec("Ubah status catatan", "Ubah status catatan ${item.optString("title")} menjadi $newStatus?", "/api/admin/notes", JSONObject().put("id", item.optString("id")).put("status", newStatus), "Status catatan diperbarui", "notes"))
                        }, modifier = Modifier.fillMaxWidth()) { Text(if (item.optString("status") == "DONE") "Buka kembali" else "Tandai selesai") }
                    }
                }
            }
            "products" -> {
                if (records.length() == 0) item { EmptyCard("Katalog produk kosong atau belum bisa dimuat.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(item.optString("name"), "${item.optString("id")} · ${item.optString("tag")}", if (item.optBoolean("active")) "Aktif" else "Nonaktif", "${rupiah(item.optLong("price"))}\n${item.optString("description")}\n${item.optString("note")}")
                        Button(onClick = { onEdit("product", item) }, modifier = Modifier.fillMaxWidth()) { Text("Edit produk") }
                    }
                }
            }
            "promos" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada kode promo.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(item.optString("code"), "${item.optString("type")} · ${item.optString("value")}", if (item.optBoolean("active")) "Aktif" else "Nonaktif", "Terpakai ${item.optLong("uses")} · Batas ${item.optString("max_uses")} · Berakhir ${item.optString("expires_at")}")
                        Button(onClick = { onEdit("promo", item) }, modifier = Modifier.fillMaxWidth()) { Text("Edit promo") }
                    }
                }
            }
            "finance" -> {
                val entries = data.optJSONArray("entries") ?: JSONArray()
                if (entries.length() == 0) item { EmptyCard("Belum ada catatan kas manual pada periode ini. Penjualan Store dihitung otomatis.") }
                items(entries.length()) { i ->
                    val item = entries.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        SimpleRecordCard("${item.optString("category")} · ${item.optString("description")}", "${item.optString("entry_date")} · ${item.optString("kind")}", item.optString("status"), rupiah(item.optLong("amount")))
                        if (item.optString("status") == "POSTED") OutlinedButton(onClick = {
                            onAction(ActionSpec("Batalkan catatan kas", "Catatan akan ditandai VOIDED dan tetap tersimpan dalam audit.", "/api/admin/finance", JSONObject().put("id", item.optString("id")).put("void", true), "Catatan kas dibatalkan", "finance"))
                        }, modifier = Modifier.fillMaxWidth()) { Text("Batalkan catatan") }
                    }
                }
            }
            "site-content" -> {
                if (records.length() == 0) item { EmptyCard("Belum ada override teks atau kartu konten.") }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(if (item.optString("kind") == "slot") "Slot ${item.optString("slot_key")}" else item.optString("title"), item.optString("page"), if (item.optBoolean("active")) "Aktif" else "Nonaktif", item.optString("body"))
                        Button(onClick = { onEdit("site-content", item) }, modifier = Modifier.fillMaxWidth()) { Text("Edit konten") }
                        if (item.optString("kind") == "card") OutlinedButton(onClick = {
                            val url = "/api/admin/site-content?id=" + URLEncoder.encode(item.optString("id"), "UTF-8")
                            onAction(ActionSpec("Hapus kartu website", "Hapus kartu ${item.optString("title")}? Slot teks tetap tidak dapat dihapus.", url, JSONObject(), "Kartu website dihapus", "site-content", "Hapus", "DELETE"))
                        }, modifier = Modifier.fillMaxWidth()) { Text("Hapus kartu") }
                    }
                }
            }
            "wiki" -> {
                val categories = data.optJSONArray("categories") ?: JSONArray()
                item {
                    Text("Rak buku (${categories.length()})", color = MainText, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onCreate("wiki-category") }, modifier = Modifier.weight(1f)) { Text("Tambah buku") }
                        Button(onClick = { onCreate("wiki-article") }, modifier = Modifier.weight(1f)) { Text("Tambah artikel") }
                    }
                }
                items(categories.length()) { i ->
                    val item = categories.optJSONObject(i) ?: JSONObject()
                    val categoryId = item.optString("id")
                    val categoryArticleCount = (0 until records.length()).count { articleIndex ->
                        records.optJSONObject(articleIndex)?.optString("category_id") == categoryId
                    }
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(
                            "${item.optString("icon")} ${item.optString("name")}",
                            "${item.optString("slug")} · ID: $categoryId",
                            if (item.optBoolean("active")) "Aktif" else "Nonaktif",
                            "${item.optString("description")}\n$categoryArticleCount artikel"
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { onCopy(categoryId) }, modifier = Modifier.weight(1f)) { Text("Salin ID") }
                            Button(onClick = { onEdit("wiki-category", item) }, modifier = Modifier.weight(1f)) { Text("Edit buku") }
                        }
                        OutlinedButton(
                            enabled = categoryArticleCount == 0,
                            onClick = {
                                val url = "/api/admin/wiki?type=category&id=" + URLEncoder.encode(categoryId, "UTF-8")
                                onAction(ActionSpec("Hapus buku Wiki", "Hapus kategori ${item.optString("name")}? Kategori yang masih berisi artikel tidak dapat dihapus.", url, JSONObject(), "Buku Wiki dihapus", "wiki", "Hapus", "DELETE"))
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(if (categoryArticleCount == 0) "Hapus buku" else "Kosongkan artikel sebelum menghapus") }
                    }
                }
                item { Text("Artikel (${records.length()})", color = MainText, fontWeight = FontWeight.Bold) }
                items(filteredIndices) { i ->
                    val item = records.optJSONObject(i) ?: JSONObject()
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        SimpleRecordCard(item.optString("title"), "${item.optString("category_name")} · ${item.optString("slug")}", item.optString("status"), item.optString("summary"))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onEdit("wiki-article", item) }, modifier = Modifier.weight(1f)) { Text("Edit artikel") }
                            OutlinedButton(onClick = {
                                val url = "/api/admin/wiki?type=article&id=" + URLEncoder.encode(item.optString("id"), "UTF-8")
                                onAction(ActionSpec("Hapus artikel Wiki", "Hapus artikel ${item.optString("title")}? Tindakan ini tidak dapat dibatalkan.", url, JSONObject(), "Artikel Wiki dihapus", "wiki", "Hapus", "DELETE"))
                            }, modifier = Modifier.weight(1f)) { Text("Hapus") }
                        }
                    }
                }
            }
            "reports" -> Unit
            "access" -> Unit
            "studio" -> Unit
            else -> item { EmptyCard("Modul ini belum memiliki data tampilan.") }
        }
    }
}

@Composable
private fun ReportSummary(data: JSONObject) {
    val summary = data.optJSONObject("summary") ?: JSONObject()
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Periode ${data.optString("from")} – ${data.optString("to")}", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Pesanan", summary.optLong("total_orders").toString(), Modifier.weight(1f))
            MetricCard("Terverifikasi", summary.optLong("paid_orders").toString(), Modifier.weight(1f), Green)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Menunggu", summary.optLong("pending").toString(), Modifier.weight(1f), Yellow)
            MetricCard("Omzet", rupiah(summary.optLong("verified_revenue")), Modifier.weight(1f), Cyan)
        }
    }
}

@Composable
private fun FinanceSummary(data: JSONObject) {
    val s = data.optJSONObject("summary") ?: JSONObject()
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Periode ${data.optString("from")} – ${data.optString("to")}", color = Muted)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Penjualan Store", rupiah(s.optLong("storeSales")), Modifier.weight(1f), Green)
            MetricCard("Pemasukan lain", rupiah(s.optLong("otherIncome")), Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricCard("Pengeluaran", rupiah(s.optLong("expenses")), Modifier.weight(1f), Yellow)
            MetricCard("Surplus estimasi", rupiah(s.optLong("estimatedNet")), Modifier.weight(1f), Cyan)
        }
    }
}

@Composable
private fun AccessScreen(data: JSONObject, role: String, onExternal: (String) -> Unit) {
    val health = data.optJSONObject("health") ?: JSONObject()
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SimpleRecordCard("Role aktif", role.uppercase(), "Diverifikasi server", "Hak Owner/Admin juga diperiksa ulang pada setiap endpoint.")
        SimpleRecordCard("Website resmi", ApiClient.BASE_URL, "HTTPS", "Endpoint aplikasi sama dengan panel web.")
        SimpleRecordCard("Rahasia akses", "Disimpan pada Android Keystore", "Terenkripsi", "Nilai secret tidak ditampilkan di dashboard atau log.")
        SimpleRecordCard("Database D1", health.optString("database", "belum diperiksa"), health.optString("schema", "belum diperiksa"), if (health.optBoolean("ok")) "Skema dan tabel wajib siap." else health.optString("error", "Pemeriksaan belum berhasil."))
        SimpleRecordCard("Konfigurasi Owner/Admin", if (health.optBoolean("adminReady")) "Siap" else "Perlu pemeriksaan", if (health.optBoolean("reentryReady")) "Tiket siap" else "Tiket belum siap", "Secret hanya ditampilkan sebagai status konfigurasi, tidak pernah nilainya.")
        OutlinedButton(onClick = { onExternal(ApiClient.BASE_URL + "/api/health") }, modifier = Modifier.fillMaxWidth()) { Text("Buka pemeriksaan kesehatan API") }
        Text("Status role berasal dari /api/admin/me. Pemeriksaan koneksi D1 dan secret berasal dari /api/health.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun EditorDialog(
    type: String,
    record: JSONObject?,
    studioJson: String,
    onStudioJsonChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: (JSONObject) -> Unit
) {
    val fields = remember(type, record) { formFields(type, record) }
    val values = remember(type, record) {
        mutableStateMapOf<String, String>().apply { fields.forEach { put(it.first, it.second) } }
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(formTitle(type), color = MainText) },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                if (type == "studio") {
                    Text("JSON konfigurasi desain SLF. Simpan hanya setelah format JSON valid.", color = Muted, style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = studioJson,
                        onValueChange = onStudioJsonChange,
                        modifier = Modifier.fillMaxWidth().height(360.dp),
                        label = { Text("Design JSON") },
                        minLines = 12,
                        maxLines = 18
                    )
                } else {
                    fields.forEach { (key, _) ->
                        val multiline = key in setOf("body", "reply", "message", "description", "note", "summary", "content", "designJson")
                        OutlinedTextField(
                            value = values[key].orEmpty(),
                            onValueChange = { values[key] = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(fieldLabel(key)) },
                            singleLine = !multiline,
                            minLines = if (multiline) 3 else 1,
                            maxLines = if (multiline) 6 else 1
                        )
                    }
                    Text("Server SLF tetap menjadi sumber validasi. Perubahan harga, role, status order, dan data penting tidak dipercaya hanya dari aplikasi.", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                val payload = if (type == "studio") JSONObject().put("designJson", studioJson) else buildPayload(type, values)
                onSave(payload)
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } },
        containerColor = Panel,
        titleContentColor = MainText,
        textContentColor = MainText
    )
}

private fun formTitle(type: String) = when (type) {
    "support" -> "Tindak lanjut tiket bantuan"
    "review" -> "Balas ulasan"
    "announcement" -> "Pengumuman SLF"
    "note" -> "Catatan tim baru"
    "product" -> "Tambah / edit produk"
    "promo" -> "Tambah / edit kode promo"
    "finance" -> "Catat kas masuk / keluar"
    "site-content" -> "Editor konten website"
    "wiki-category" -> "Tambah / edit buku Wiki"
    "wiki-article" -> "Tambah / edit artikel Wiki"
    "studio" -> "SLF Studio · Design JSON"
    else -> "Edit data"
}

private fun createType(page: String) = when (page) {
    "support" -> "support"
    "reviews" -> "review"
    "announcements" -> "announcement"
    "notes" -> "note"
    "products" -> "product"
    "promos" -> "promo"
    "finance" -> "finance"
    "site-content" -> "site-content"
    "wiki" -> "wiki-article"
    else -> page
}

private fun formFields(type: String, item: JSONObject?): List<Pair<String, String>> {
    val r = item ?: JSONObject()
    fun s(key: String, default: String = "") = r.optString(key, default).let { if (it == "null") default else it }
    return when (type) {
        "support" -> listOf("id" to s("id"), "status" to s("status", "OPEN"), "reply" to s("admin_reply"))
        "review" -> listOf("orderId" to s("order_id"), "reply" to s("reply"), "adminName" to s("admin_name", "Tim SLF"))
        "announcement" -> listOf("id" to s("id"), "title" to s("title"), "body" to s("body"), "active" to if (r.has("active")) r.optBoolean("active").toString() else "true", "startsAt" to s("starts_at"), "endsAt" to s("ends_at"))
        "note" -> listOf("title" to "", "category" to "Operasional", "priority" to "MEDIUM", "body" to "")
        "product" -> listOf("id" to s("id"), "name" to s("name"), "price" to s("price"), "icon" to s("icon", "✦"), "tag" to s("tag", "Store"), "description" to s("description"), "note" to s("note"), "active" to if (r.has("active")) r.optBoolean("active").toString() else "true")
        "promo" -> listOf("code" to s("code"), "type" to s("type", "percent"), "value" to s("value"), "active" to if (r.has("active")) r.optBoolean("active").toString() else "true", "maxUses" to s("max_uses"), "expiresAt" to s("expires_at"))
        "finance" -> listOf("kind" to "INCOME", "entryDate" to LocalDate.now().toString(), "category" to "Pemasukan lain", "amount" to "", "description" to "", "reference" to "")
        "site-content" -> listOf("id" to s("id"), "kind" to s("kind", "card"), "page" to s("page", "home"), "slotKey" to s("slot_key", "home.lead"), "title" to s("title"), "body" to s("body"), "imageUrl" to s("image_url"), "active" to if (r.has("active")) r.optBoolean("active").toString() else "true", "startsAt" to s("starts_at"), "endsAt" to s("ends_at"))
        "wiki-category" -> listOf("id" to s("id"), "name" to s("name"), "slug" to s("slug"), "description" to s("description"), "icon" to s("icon", "📚"), "sortOrder" to s("sort_order", "10"), "active" to if (r.has("active")) r.optBoolean("active").toString() else "true")
        "wiki-article" -> listOf("id" to s("id"), "categoryId" to s("category_id"), "title" to s("title"), "slug" to s("slug"), "summary" to s("summary"), "content" to s("content"), "icon" to s("icon", "📖"), "sortOrder" to s("sort_order", "10"), "status" to s("status", "published"), "legacyUrl" to s("legacy_url"))
        else -> emptyList()
    }
}

private fun buildPayload(type: String, values: Map<String, String>): JSONObject {
    fun v(key: String) = values[key].orEmpty().trim()
    fun bool(key: String) = v(key).equals("true", true) || v(key) == "1"
    return when (type) {
        "support" -> JSONObject().put("id", v("id")).put("status", v("status")).put("reply", v("reply"))
        "review" -> JSONObject().put("orderId", v("orderId")).put("reply", v("reply")).put("adminName", v("adminName"))
        "announcement" -> JSONObject().put("id", v("id")).put("title", v("title")).put("body", v("body")).put("active", bool("active")).put("startsAt", if (v("startsAt").isBlank()) JSONObject.NULL else v("startsAt")).put("endsAt", if (v("endsAt").isBlank()) JSONObject.NULL else v("endsAt"))
        "note" -> JSONObject().put("title", v("title")).put("category", v("category")).put("priority", v("priority")).put("body", v("body"))
        "product" -> JSONObject().put("id", v("id")).put("name", v("name")).put("price", v("price").toLongOrNull() ?: 0L).put("icon", v("icon")).put("tag", v("tag")).put("description", v("description")).put("note", v("note")).put("active", bool("active"))
        "promo" -> JSONObject().put("code", v("code")).put("type", v("type")).put("value", v("value").toDoubleOrNull() ?: 0.0).put("active", bool("active")).put("maxUses", v("maxUses").toIntOrNull() ?: JSONObject.NULL).put("expiresAt", if (v("expiresAt").isBlank()) JSONObject.NULL else v("expiresAt"))
        "finance" -> JSONObject().put("kind", v("kind")).put("entryDate", v("entryDate")).put("category", v("category")).put("amount", v("amount").toLongOrNull() ?: 0L).put("description", v("description")).put("reference", v("reference"))
        "site-content" -> JSONObject().put("id", v("id")).put("kind", v("kind")).put("page", v("page")).put("slotKey", v("slotKey")).put("title", v("title")).put("body", v("body")).put("imageUrl", v("imageUrl")).put("active", bool("active")).put("startsAt", if (v("startsAt").isBlank()) JSONObject.NULL else v("startsAt")).put("endsAt", if (v("endsAt").isBlank()) JSONObject.NULL else v("endsAt"))
        "wiki-category" -> JSONObject().put("type", "category").put("id", v("id")).put("name", v("name")).put("slug", v("slug")).put("description", v("description")).put("icon", v("icon")).put("sortOrder", v("sortOrder").toIntOrNull() ?: 10).put("active", bool("active"))
        "wiki-article" -> JSONObject().put("type", "article").put("id", v("id")).put("categoryId", v("categoryId")).put("title", v("title")).put("slug", v("slug")).put("summary", v("summary")).put("content", v("content")).put("icon", v("icon")).put("sortOrder", v("sortOrder").toIntOrNull() ?: 10).put("status", v("status")).put("legacyUrl", v("legacyUrl"))
        else -> JSONObject()
    }
}

@Composable
private fun SimpleRecordCard(title: String, subtitle: String, status: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title.ifBlank { "—" }, Modifier.weight(1f), color = MainText, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (status.isNotBlank()) StatusChip(status, statusColor(status))
            }
            if (subtitle.isNotBlank()) Text(subtitle, color = Muted, style = MaterialTheme.typography.bodySmall)
            if (detail.isNotBlank()) Text(detail, color = MainText, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun MetricCard(label: String, value: String, modifier: Modifier = Modifier, accent: Color = Cyan) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(7.dp).background(accent, CircleShape))
            Text(label, color = Muted, style = MaterialTheme.typography.labelMedium)
            Text(value, color = accent, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun StatusChip(text: String, color: Color) {
    Surface(color = color.copy(alpha = .13f), contentColor = color, shape = CircleShape) {
        Text(text.replace('_', ' '), Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
private fun QuickButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    FilledTonalButton(onClick = onClick, modifier = modifier.height(64.dp), shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(5.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null); Text(label, style = MaterialTheme.typography.labelSmall) }
    }
}

@Composable
private fun EmptyCard(message: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Text(message, Modifier.padding(18.dp), color = Muted)
    }
}

private fun moduleDescription(page: String) = when (page) {
    "orders" -> "Verifikasi pembayaran, proses, selesaikan, atau batalkan sesuai status server."
    "tickets" -> "Daftar tiket Re-entry dan status pengajuan pemain."
    "support" -> "Periksa pertanyaan pemain dan simpan tindak lanjut di D1."
    "reviews" -> "Balasan yang disimpan akan tampil pada Store publik."
    "customers" -> "Data pelanggan dan pengeluaran yang telah terverifikasi."
    "activity" -> "Jejak tindakan Owner/Admin yang tercatat oleh server."
    "finance" -> "Pemasukan lain dan pengeluaran. Penjualan Store dihitung otomatis."
    "site-content" -> "Ubah slot teks atau kartu informasi pada halaman publik."
    "wiki" -> "Kelola kategori buku serta artikel Wiki."
    else -> "Data operasional SLF tersimpan pada server utama."
}

private fun moduleIcon(id: String) = when (id) {
    "home" -> Icons.Default.Dashboard
    "orders" -> Icons.Default.ReceiptLong
    "tickets" -> Icons.Default.AssignmentTurnedIn
    "support" -> Icons.Default.Chat
    "reviews" -> Icons.Default.Reviews
    "customers" -> Icons.Default.Group
    "activity" -> Icons.Default.History
    "announcements" -> Icons.Default.Campaign
    "notes" -> Icons.Default.Assignment
    "products" -> Icons.Default.Storefront
    "promos" -> Icons.Default.Percent
    "reports" -> Icons.Default.FactCheck
    "finance" -> Icons.Default.AccountBalance
    "site-content" -> Icons.Default.Web
    "wiki" -> Icons.Default.LibraryBooks
    "studio" -> Icons.Default.Edit
    "access" -> Icons.Default.Lock
    else -> Icons.Default.Menu
}

private fun statusColor(status: String): Color = when (status.uppercase()) {
    "COMPLETED", "ACTIVE", "PAID", "RESOLVED", "DONE", "POSTED" -> Green
    "PENDING_PAYMENT", "PENDING", "OPEN", "WAITING_PLAYER", "WAITING_PAYMENT" -> Yellow
    "CANCELLED", "CLOSED", "VOIDED", "EXPIRED" -> Red
    "PROCESSING", "IN_PROGRESS", "SUBMITTED" -> Lavender
    else -> Muted
}

private fun rupiah(amount: Long): String = "Rp" + String.format("%,d", amount).replace(',', '.')
private fun fieldLabel(key: String) = when (key) {
    "id" -> "ID (kosongkan untuk data baru)"
    "orderId" -> "Nomor order"
    "status" -> "Status (gunakan nilai yang sesuai)"
    "reply" -> "Balasan"
    "adminName" -> "Nama admin"
    "active" -> "Aktif? true / false"
    "startsAt" -> "Mulai (ISO-8601, opsional)"
    "endsAt" -> "Berakhir (ISO-8601, opsional)"
    "name" -> "Nama"
    "price" -> "Harga (angka Rupiah)"
    "maxUses" -> "Batas penggunaan (kosong = tanpa batas)"
    "expiresAt" -> "Kedaluwarsa (ISO-8601, opsional)"
    "entryDate" -> "Tanggal (YYYY-MM-DD)"
    "kind" -> "Jenis / tipe"
    "slotKey" -> "Slot teks (contoh home.lead)"
    "imageUrl" -> "URL gambar HTTPS atau path aset SLF"
    "categoryId" -> "ID kategori buku"
    "sortOrder" -> "Urutan tampil"
    "legacyUrl" -> "URL artikel lama (opsional)"
    else -> key.replaceFirstChar { it.uppercase() }
}
