package id.legacyfrontier.admin

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONArray

/**
 * Background fallback notification checker. WorkManager periodic jobs are deferrable
 * and run no more frequently than the platform's 15-minute minimum interval.
 * This is not a real-time push transport; FCM requires a server-side sender integration.
 */
class AdminNotificationWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val secret = SecureStore.read(applicationContext) ?: return Result.success()
        return try {
            val orders = ApiClient.get("/api/admin/orders", secret).optJSONArray("orders") ?: JSONArray()
            val supports = ApiClient.get("/api/admin/support", secret).optJSONArray("tickets") ?: JSONArray()
            val tickets = ApiClient.get("/api/admin/tickets", secret).optJSONArray("tickets") ?: JSONArray()
            val prefs = applicationContext.getSharedPreferences("slf_admin_notification_state", Context.MODE_PRIVATE)
            val previousOrders = prefs.getStringSet("orders", emptySet())?.toSet().orEmpty()
            val previousSupports = prefs.getStringSet("supports", emptySet())?.toSet().orEmpty()
            val previousTickets = prefs.getStringSet("tickets", emptySet())?.toSet().orEmpty()
            val currentOrders = ids(orders) { it.optString("id") }
            val currentSupports = ids(supports) { it.optString("id") }
            val currentTickets = ids(tickets) { it.optString("id") + ":" + it.optString("status") }

            if (!prefs.getBoolean("initialized", false)) {
                prefs.edit().putStringSet("orders", currentOrders)
                    .putStringSet("supports", currentSupports)
                    .putStringSet("tickets", currentTickets)
                    .putBoolean("initialized", true).apply()
                return Result.success()
            }

            val orderCount = currentOrders.minus(previousOrders).size
            val supportCount = currentSupports.minus(previousSupports).size
            val ticketCount = currentTickets.minus(previousTickets).count { it.substringAfterLast(':') in setOf("PENDING", "SUBMITTED", "WAITING_ADMIN") }
            prefs.edit().putStringSet("orders", currentOrders)
                .putStringSet("supports", currentSupports)
                .putStringSet("tickets", currentTickets).apply()

            val total = orderCount + supportCount + ticketCount
            if (total > 0) showNotification(orderCount, supportCount, ticketCount)
            Result.success()
        } catch (error: ApiException) {
            if (error.status == 401 || error.status == 403) {
                SecureStore.clear(applicationContext)
                Result.success()
            } else Result.retry()
        } catch (_: Exception) {
            Result.retry()
        }
    }

    private fun ids(array: JSONArray, id: (org.json.JSONObject) -> String): Set<String> =
        buildSet { for (i in 0 until array.length()) array.optJSONObject(i)?.let { id(it).takeIf(String::isNotBlank)?.let(::add) } }

    private fun showNotification(orders: Int, support: Int, tickets: Int) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "slf_admin_operations"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(channelId, "Aktivitas SLF Admin", NotificationManager.IMPORTANCE_DEFAULT)
                    .apply { description = "Pemberitahuan order, bantuan, dan re-entry SLF" }
            )
        }
        val parts = buildList {
            if (orders > 0) add("$orders pesanan baru")
            if (support > 0) add("$support tiket bantuan baru")
            if (tickets > 0) add("$tickets aktivitas re-entry baru")
        }
        val intent = Intent(applicationContext, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pending = PendingIntent.getActivity(
            applicationContext, 7001, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(applicationContext, channelId)
            .setSmallIcon(R.drawable.ic_stat_slf)
            .setContentTitle("Aktivitas baru · SLF Admin")
            .setContentText(parts.joinToString(" · "))
            .setStyle(Notification.BigTextStyle().bigText(parts.joinToString("\n")))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setVisibility(Notification.VISIBILITY_PRIVATE)
            .build()
        manager.notify(7001, notification)
    }
}
