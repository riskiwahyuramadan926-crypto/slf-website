# SLF Admin — Android Native

Project Android native untuk ruang operasional Survival Legacy Frontier. Aplikasi ini **bukan WebView dan tidak membuka halaman `/admin/`**. UI dibuat dengan Kotlin + Jetpack Compose dan berkomunikasi langsung dengan Cloudflare Pages Functions milik SLF.

## Modul yang tersedia

- Ringkasan operasional dan statistik order.
- Pesanan & transaksi: detail order, verifikasi pembayaran manual, mulai proses, selesaikan, batalkan, salin detail, dan hubungi pembeli.
- Tiket Re-entry: daftar tiket, tandai selesai, dan pulihkan tiket yang sudah selesai sesuai validasi API.
- Pusat Bantuan: baca tiket, ubah status, simpan balasan, dan hubungi pemain.
- Ulasan: baca rating dan menyimpan balasan publik Admin.
- Pelanggan dan aktivitas: data pelanggan, pengeluaran terverifikasi, serta audit aktivitas.
- Pengumuman dan catatan tim.
- Owner-only: produk, kode promo, statistik/laporan, kas & keuangan, Editor Website, Perpustakaan Wiki (termasuk tambah/edit/hapus buku dan artikel), SLF Studio, serta pemeriksaan akses dan D1. Editor Website mendukung edit slot teks/kartu dan hapus kartu; SLF Studio di aplikasi menyimpan konfigurasi desain JSON, bukan editor visual drag-and-drop penuh.

Aplikasi menggunakan endpoint dan aturan otorisasi yang sama dengan panel web. Validasi harga, batas tiga tiket Re-entry per pemain/season, aturan status order, dan pemisahan hak Owner/Admin tetap dilakukan oleh server. Aplikasi tidak menyimpan data transaksi sebagai sumber kebenaran lokal.

## Keamanan

- Login memakai `OWNER_SECRET` atau `ADMIN_SECRET` yang sudah dipasang pada Cloudflare Pages.
- Secret disimpan terenkripsi menggunakan AES-GCM dengan kunci Android Keystore.
- Semua request memakai HTTPS dan `Authorization: Bearer ...`.
- Tidak ada secret yang ditulis ke source code, BuildConfig, atau file konfigurasi.
- `FLAG_SECURE` diaktifkan untuk mengurangi risiko screenshot pada layar operasional yang memuat data pelanggan.
- API server tetap menjadi penentu hak akses; menyembunyikan menu Owner di aplikasi bukan pengganti otorisasi server.

## Notifikasi

Versi sumber ini memiliki pemeriksaan latar belakang menggunakan Android WorkManager. Pemeriksaan dijadwalkan pada interval minimum 15 menit dan Android dapat menundanya sesuai kebijakan baterai/jaringan. Notifikasi lokal muncul untuk order, tiket bantuan, dan aktivitas pengajuan Re-entry baru.

**Ini bukan push real-time.** Backend SLF saat ini belum memiliki pengirim push server. Untuk notifikasi instan ketika server menerima aktivitas, perlu proyek Firebase, konfigurasi FCM, endpoint pendaftaran token perangkat, serta pengirim FCM di Cloudflare. Jangan menganggap notifikasi instan aktif sebelum integrasi server tersebut dipasang dan diuji.

## Membangun APK

Persyaratan build:

- Android Studio yang mendukung Android Gradle Plugin 9.1.1 dan Kotlin Compose plugin 2.4.20.
- JDK 17 atau lebih baru yang didukung Gradle 9.3.1.
- Android SDK Platform 36 dan Build Tools yang sesuai.
- Koneksi internet pada komputer build untuk mengunduh Gradle dan dependensi Maven pertama kali.

Langkah:

1. Buka folder `slf-admin-android` melalui Android Studio.
2. Tunggu Gradle Sync selesai.
3. Jalankan `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`).
4. APK debug akan berada di `app/build/outputs/apk/debug/app-debug.apk`.
5. Untuk rilis, buat signing key sendiri di Android Studio dan gunakan build variant Release. Jangan memasukkan keystore/password signing ke GitHub.

Package ID: `id.legacyfrontier.admin`

## Batas verifikasi pada paket ini

Source project sudah dibuat dan pemeriksaan statis dasar (struktur XML, konfigurasi, dan pemeriksaan sintaks Kotlin tanpa library Android) sudah dilakukan. APK **belum dikompilasi atau diuji di emulator/perangkat** pada lingkungan pembuatannya: Android SDK/Build Tools tidak tersedia, dan unduhan Gradle/dependensi diblokir karena DNS jaringan build tidak dapat menyelesaikan `services.gradle.org`. Karena itu belum ada klaim bahwa APK ini sudah siap dipasang. Jalankan build serta uji navigasi, izin notifikasi, login Owner/Admin, dan alur mutasi dengan akun uji sebelum dipakai operasional.

Transaksi pembayaran nyata tidak disimulasikan. Tombol verifikasi tetap memerlukan pengecekan transaksi yang benar-benar masuk di DANA Bisnis, sesuai aturan panel SLF.

## Kesesuaian dengan aturan proyek SLF

Implementasi aplikasi mengikuti kontrak repository SLF dan `AGENTS.md`:

- Tidak mengubah website, API, skema D1, harga, season, kuota Re-entry, atau aturan pembayaran.
- Menggunakan API Cloudflare Pages yang sudah ada; tidak membuat database/backend pengganti.
- Owner-only modules mengikuti daftar akses yang dikembalikan `/api/admin/me`; endpoint server tetap melakukan pemeriksaan role.
- Tidak menganggap screenshot sebagai bukti pembayaran. Verifikasi tetap harus dicocokkan dengan transaksi DANA Bisnis yang benar-benar masuk.
- Tidak menambahkan secret ke source atau menyimpan data transaksi sebagai sumber kebenaran di perangkat.
- Data pelanggan/keuangan dilindungi dengan `FLAG_SECURE`; backup Android dimatikan.
- Permintaan API hanya HTTPS ke domain resmi SLF.

## Pemeriksaan source yang tersedia

Jalankan dari folder project:

```bash
python3 tests/check_project.py
```

Pemeriksaan ini memastikan modul operasional, endpoint API, konfigurasi HTTPS, Android Keystore, tidak adanya WebView, dan tidak adanya secret yang ditulis sebagai nilai source. Ini pemeriksaan statis, bukan pengganti build Gradle atau pengujian perangkat.

## Status akhir paket

- Source Android native dan project Android Studio: tersedia.
- Pemeriksaan statis project: lulus.
- Validasi XML Android: lulus.
- Build APK: belum dapat dijalankan pada lingkungan pembuat karena `services.gradle.org` tidak dapat di-resolve (DNS), dan Android SDK tidak tersedia.
- Deploy/akses Cloudflare dan pengujian transaksi produksi: tidak dilakukan oleh paket ini.
- Sebelum operasional, build APK di Android Studio, uji login kedua role, pastikan endpoint di production aktif, uji alur dengan data uji, dan uji notifikasi di perangkat. Jangan gunakan verifikasi pembayaran palsu atau transaksi nyata sebagai tes.
